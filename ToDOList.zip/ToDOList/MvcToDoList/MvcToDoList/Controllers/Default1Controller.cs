﻿using MvcToDoList.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Providers.Entities;

namespace MvcToDoList.Controllers
{
    public class Default1Controller : Controller
    {
        //
        // GET: /Default1/

        public ActionResult Index()
        {
            return View();
        }


        public ActionResult ListaProduto()
        {
            return View("ListaProduto", ListarProdutos());
        }


        //
        // GET: /Default1/Details/5

        public ActionResult Details(int id)
        {
            return View();
        }

        //
        // GET: /Default1/Create

        public ActionResult Create()
        {



            return View();
        }

        //
        // POST: /Default1/Create

        [HttpPost]
        public ActionResult Create(Produto collection)
        {
            try
            {
                AdicionarProduto(collection);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Default1/Edit/5

        public ActionResult Edit(int id)
        {
            return View();
        }

        //
        // POST: /Default1/Edit/5

        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Default1/Delete/5

        public ActionResult Delete(int id)
        {
            return View();
        }

        //
        // POST: /Default1/Delete/5

        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }



        public List<Produto> ListarProdutos()
        {
            List<Produto> Lista = new List<Produto>();

            if (Session["Lista"] != null)
            {
                Lista = (List<Produto>)Session["Lista"];
            }
            Session["Lista"] = Lista;


            return Lista;
        }


        public void AdicionarProduto(Produto Item)
        {
            List<Produto> Lista = new List<Produto>();

            Lista = ListarProdutos();

            int contador = 0;

            contador = Lista.Count;

            Lista.Add(new Produto { Id = contador + 1, Nome = Item.Nome });

            Session["Lista"] = Lista;

        }


    }
}
